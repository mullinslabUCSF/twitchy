function [masterTRACK,masterMSD,masterLL] = multi_MSD_twitch(data_dir,nameLIST,tFRAC,thresh)
% twitch_MSD - goes to a directory; opens a data file; and analyzes the
% motility by calculating mean square displacement versis time
% RDM - 9/8/2023

% data_dir - like it says this is the directory containing the data file
% nameLIST - cell array of strings with the name of data text files
% tFRAC - fracti0n of the track that is analyzed for MSD plot
% thresh - fractional increase threshold for motility

% masterTRACK - combined tracks from all identified cells
% masterMSD - cell containing combined MSD plots
% masterLL - cell containing the combined log-log MSD and delta t data

nf = size(nameLIST);
numfiles = nf(1);

[masterTRACK,masterMSD] = twitch_MSD(data_dir,nameLIST{1},tFRAC,thresh);

for i=2:numfiles
    [ithTRACK,ithMSD] = twitch_MSD(data_dir,nameLIST{i},tFRAC,thresh);
    [masterMSD] = masterCELL(masterMSD,ithMSD);
end

%masterLL = loglog_parse(masterMSD);
masterLL = masterMSD;

return
end