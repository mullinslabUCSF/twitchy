function [LLslopes,ll_data] = loglog_parse_w(inCELL,fname)
% simple function to convert all the MSD trajectories in a cell array
% (inCELL) into log-log form; adjust the data to start at 0 and then find
% the slopes of all the lines

% the cell arrays have a form set by twitch_MSD()
% inCELL{,1} - trackID
% inCELL{,2} - track length
% inCELL{,3} - time vector
% inCELL{,4} - Mean Square Displacement vector
% inCELL{,5} - number of observations for each point
% inCELL{,6} - slope of MSD vs. time linearfit
% inCELL{,7} - over cutoff flag

% firuge out the number of tracks
cs = size(inCELL);
num_tr = cs(1);

% make a cell array to hold the logarithmic data
ll_data = cell(num_tr,3);
% 1, 2, 3 = x-data, y-data, slope

LLslopes = zeros(num_tr,1);
LLinrcpt = zeros(num_tr,1);

% open the data file to save all the curves in
%dftag = fopen(fname);

% run through the data and calculate slopes of log-log plots of MSD vs time
figure(1)
hold on
for i=1:num_tr

    if length(inCELL{i,3})==0
        i
    end

    % deal with potential zeros
    if inCELL{i,3}(1) == 0
        inCELL{i,3} = inCELL{i,3} + inCELL{i,3}(2);
    end

    if inCELL{i,4}(1) == 0
        inCELL{i,4} = inCELL{i,4} + inCELL{i,4}(2);
    end

    % load up the time vector
    x = log(inCELL{i,3});
    % load up the MSD vector
    y = log(inCELL{i,4});

    % shift the data to pass through the origin
     x = x - x(1);
     y = y - y(1);

    % compute the slope of the line
    LLslopes(i) = slope(x,y);

    % save the log-log data to the new cell structure
    ll_data{i,1} = x;
    ll_data{i,2} = y;
    ll_data{i,3} = LLslopes(i);

    % now plot the results
    plot(x,y,"MarkerFaceColor",[0.5+0.5*rand 0.5+0.5*rand 0.5+0.5*rand]);
    %plot(x,LLslopes(i)*x,"Color", [0 0 0])

end
hold off

figure(2)
histogram(LLslopes)

writecell(ll_data,fname);

return
end

function m = slope(X,Y)
% slope - calculates a linear fit of Y versus X and returns the slope
% X and Y are the ordinate and abcissa

 % use linear regression to find the best-fit slope of a line that runs
 % through the origin: i.e. y = mx
 % to deal with large slopes, we will calculate slope both ways
    
 % since y = mx, the 'estimator matrix' is just X
 % the observation vector is Y
 % the results are contained in m
    
 m = (X'*X)\X'*Y;

    return
end