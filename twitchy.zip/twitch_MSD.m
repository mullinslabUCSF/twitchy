function [mastrack,masMSD] = twitch_MSD(file_dir,dfname,tracFRAC,cutoff)
% twitch_MSD - goes to a directory; opens a data file; and analyzes the
% motility by calculating mean square displacement versis time
% RDM - 8/7/2023

% file_dir - like it says this is the directory containing the data file
% dfname - the name of a text file containing the data
% tstep - time between frames
% tracFRAC - fracti0n of the track that is analyzed for MSD plot
% cutoff - fractional increase cutoff for motility

% h_len - length of the header (in lines)
h_len = 4;

% set the return directory to the current one
ret_dir = pwd;
% go to the specified data directory
cd(file_dir)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% first, we count all of the lines and traces in the data file %%%%%%%%%%%
% open the data file
dftag = fopen(dfname);
% number of data points
npts = 0;
% get the header (first h_len lines)
for i=1:h_len
    this_line = fgetl(dftag);
end
% now run through the data file and read every line
while(this_line ~= -1) 
    this_line = fgetl(dftag);
    npts = npts+1;
end
% close the data file nicely
fclose('all');
% correct the number of points
npts = npts-1;    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% next we will read the data and pull out position and time info %%%%%%%%

% initialize data arrays
% position - information on x,y position and time
spacetime = zeros(npts,3);
% trackID - like it says, the ID number of the current track
trackID = zeros(npts,1);

% open the data file
dftag = fopen(dfname);
% deal with the header
for i=1:h_len
    this_line = fgetl(dftag);
end

% now run through the data file and read every line
for i=1:npts
    this_line = fgetl(dftag);    
    % find all the COMMAs in the current line
    CMind = findstr(char(44),this_line); % ascii code for comma is 44

    % pull out the numeric data (discarding the first position)
    dline = this_line(CMind(1)+1:length(this_line));
    % convert the string into a set of numbers
    [s]=sscanf(dline,'%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f');

    % pull out the track ID
    trackID(i) = s(2);
    % pull out the x-y values and time for the position
    spacetime(i,1) = s(4);
    spacetime(i,2) = s(5); 
    spacetime(i,3) = s(7);
end

% close the data file nicely
fclose('all');
% go back home to the original directory
cd(ret_dir)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% next, identify the tracks, count them, and sort them on time %%%%%%%%%%%

% tr_list is a non-redunand list of track IDs
tr_list = unique(trackID,'stable');
% count the number of tracks
num_tr = length(tr_list);
% set up a vector to hold all the track length information
tr_len = zeros(num_tr,1);

% now create a preliminary master track cell array
mastrack0 = cell(num_tr,5);
% mastrack{1} - trackID
% mastrack{2} - track length
% mastrack{3} - x position vector
% mastrack{4} - y position vector
% mastrack{5} - time (adjusted to start at t=0)

% running index for position vectors
k=1;
% running index for tracks longer than 5 points
n=0;
% run through the track IDs; pull out the tracks; and sort on time
for i=1:num_tr
    % save the track ID
    mastrack0{i,1} = tr_list(i);

    % calculate the track length
    dum = trackID - tr_list(i);
    tr_len(i) = npts - nnz(dum);
    % save the track length
    mastrack0{i,2} = tr_len(i);
    % count tracks above cutoff length
    if mastrack0{i,2} > 10
        n=n+1;
    end
    
    % load the time trace into a temporary vector for sorting
    timetemp = spacetime(k:k+tr_len(i)-1,3);
    spacetemp = spacetime(k:k+tr_len(i)-1,1:2);
    % sort on time
    [timetemp,order] = sort(timetemp);

    % save the sorted position data
    mastrack0{i,3} = spacetemp(order,1);
    mastrack0{i,4} = spacetemp(order,2);
    mastrack0{i,5} = timetemp - timetemp(1);
    
    % increment the index k
    k=k+tr_len(i);
end

% set up the MSD cell array
masMSD0 = cell(num_tr,7);
% masMSD{,1} - trackID
% masMSD{,2} - track length
% masMSD{,3} - time vector
% masMSD{,4} - Mean Square Displacement vector
% masMSD{,5} - number of observations for each point
% masMSD{,6} - slope of MSD vs. time linear fit
% masMSD{,7} - over cutoff flag

% minAVG - is the minimum number of points averaged for each track MSD
minAVG = zeros(num_tr,1);
% rise - how much higher is the end of the trace than the beginning?
rise = zeros(num_tr,1);
for i=1:num_tr
    % mlength is the length of the MSD versus time plot
    mlength = ceil(tracFRAC*tr_len(i));

    masMSD0{i,1} = tr_list(i);
    masMSD0{i,2} = mlength;
    masMSD0{i,3} = mastrack0{i,5}(1:mlength);
    [masMSD0{i,4},masMSD0{i,5}] = MSDcalc(mastrack0{i,3},mastrack0{i,4},tracFRAC);
    minAVG(i) = masMSD0{i,5}(mlength);
    %rise(i) = mean(masMSD{i,4}(floor(0.8*mlength):mlength))/mean(masMSD{i,4}(1:ceil(0.2*mlength)));
    rise(i) = slope(masMSD0{i,3},masMSD0{i,4});
    if rise(i)>cutoff
        masMSD0{i,7} = 1;
    else
        masMSD0{i,7} = 0;
    end
    % store the slope of MSD versus time
    masMSD0{i,6} = rise(i);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% make new master cells that exclude the short tracks
mastrack = cell(n,5);
masMSD = cell(n,7);
k=0;
for i=1:num_tr
    % look for tracks that are too short
    if mastrack0{i,2} > 10
        k=k+1;

        % new track cell
        mastrack{k,1}=mastrack0{i,1};
        mastrack{k,2}=mastrack0{i,2};
        mastrack{k,3}=mastrack0{i,3};
        mastrack{k,4}=mastrack0{i,4};
        mastrack{k,5}=mastrack0{i,5};

        % new MSD cell
        masMSD{k,1}=masMSD0{i,1};
        masMSD{k,2}=masMSD0{i,2};
        masMSD{k,3}=masMSD0{i,3};
        masMSD{k,4}=masMSD0{i,4};
        masMSD{k,5}=masMSD0{i,5};
        masMSD{k,6}=masMSD0{i,6};
        masMSD{k,7}=masMSD0{i,7};

    else
        dfname
        i
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % calculate a bootstrapped standard deviation and determine a cutoff
% % amplitude for calling a spot motile (~2*STD)
% 
% % randLOW - is all the rise() values below 1.0
% randLOW = zeros(num_tr,1);
% % calculate some bootstrap SD values for rise()
% k=0;
% for i=1:num_tr
%     if rise(i)<1
%         k=k+1;
%         randLOW(k)=rise(i);
%     end
% end
% numLOW = nnz(randLOW);
% % center randLOW around zero
% randLOW = randLOW-1;
% randBOOT = randLOW(1:numLOW);
% randBOOT = [randBOOT;-randBOOT];
% CO = 1.5*std(randBOOT);
% for i=1:num_tr
%     if rise(i)>1+CO
%         masMSD{i,6}=1;
%     else
%         masMSD{i,6}=0;
%     end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now do some plotting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
colorspace = zeros(num_tr,3);
figure(1)
hold on
for i=1:num_tr
    % set the color for this track
    if masMSD0{i,7}==1
        colorspace(i,:) = [0.4+0.6*rand 0.4+0.6*rand 0.4+0.6*rand];
    else
        colorspace(i,:) = [0 0 0];
    end
    plot(mastrack0{i,3},mastrack0{i,4},'ok','MarkerFaceColor',colorspace(i,:))
end
hold off

% do more plotting
figure(2)
hold on
for i=1:num_tr
    plot(masMSD0{i,3},masMSD0{i,4},'ok','MarkerFaceColor',colorspace(i,:))
    plot(masMSD0{i,3},masMSD0{i,6}*masMSD0{i,3})
end
hold off

% plot some quality control parameters
figure(3)
plot(1:num_tr,minAVG);

figure(4)
hold on
plot(1:num_tr,rise)
plot(1:num_tr,zeros(num_tr,1))
plot(1:num_tr,cutoff*ones(num_tr,1))
hold off

figure(5)
histogram(rise)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

return
end

function [MSD,OBS] = MSDcalc(X,Y,f)
% MSD_calc - calculates MSD for x and y track data
% RDM - 8/8/2023

% initialize the outputs
% MSD=zeros(length(X)-1,1);
% OBS=zeros(length(X)-1,1);
MSD=zeros(ceil(f*length(X)),1);
OBS=zeros(ceil(f*length(X)),1);

%for i=1:length(X)-1
for i=1:ceil(f*length(X))
    for j=1:length(X)-i
        MSD(i) = MSD(i)+(X(j+i)-X(j))^2+(Y(j+i)-Y(j))^2;
    end
    OBS(i) = length(X)-i;
    MSD(i) = MSD(i)/OBS(i);
end

return 
end

function m = slope(X,Y)
% slope - calculates a linear fit of Y versus X and returns the slope
% X and Y are the ordinate and abcissa

 % use linear regression to find the best-fit slope of a line that runs
 % through the origin: i.e. y = mx
 % to deal with large slopes, we will calculate slope both ways
    
 % since y = mx, the 'estimator matrix' is just X
 % the observation vector is Y
 % the results are contained in m
    
 m = (X'*X)\X'*Y;

    return
end
