function [npts,dcols] = open_CSV(file_dir,dfname,head,numcol,targets)
% open_CSV - goes to a directory; opens a data file; and returns data
% RDM - 8/17/2023

% file_dir - like it says this is the directory containing the data file
% dfname - the name of a text file containing the data
% head - number of lines in file header
% numcol - number of data columns on the file
% targets - target data columns to extract

% set the return directory to the current one
ret_dir = pwd;
% go to the specified data directory
cd(file_dir)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% first, we count all of the lines and traces in the data file %%%%%%%%%%%
% open the data file
dftag = fopen(dfname);
% number of data points
npts = 0;
% get the header (first head lines)
for i=1:head
    this_line = fgetl(dftag);
end
% now run through the data file and read every line
while(this_line ~= -1) 
    this_line = fgetl(dftag);
    npts = npts+1;
end
% close the data file nicely
fclose('all');
% correct the number of points
npts = npts-1;    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% next we will read the data and pull out the requested columns %%%%%%%%%

% initialize data arrays
% position - information on x,y position and time
dcols = zeros(npts,length(targets));

% open the data file
dftag = fopen(dfname);
% deal with the header
for i=1:head
    this_line = fgetl(dftag);
end

% now run through the data file and read every line
for i=1:npts
    this_line = fgetl(dftag);    
    % find all the COMMAs in the current line
    CMind = findstr(char(44),this_line); % ascii code for comma is 44

    % make a template for sscanf
    stemplate = '%f';
    for j=2:numcol
        stemplate = [stemplate ',%f'];
    end
    % pull out the numeric data (discarding the first column)
    dline = this_line(CMind(1)+1:length(this_line));
    % convert the string into a set of numbers
    [s]=sscanf(dline,stemplate);

    % pull out the relevant columns
    for j=1:length(targets)
        dcols(i,j) = s(targets(j)-1);
    end
end

% close the data file nicely
fclose('all');
% go back home to the original directory
cd(ret_dir)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    return
end
