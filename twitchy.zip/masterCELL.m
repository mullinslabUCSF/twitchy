function [outCELL] = masterCELL(cell1,cell2)
% simple function to catenate contents of two data analysis cell arrays
% into one output cell array

% the cell arrays have a form set by twitch_MSD()
% outCELL{,1} - trackID
% outCELL{,2} - track length
% outCELL{,3} - time vector
% outCELL{,4} - Mean Square Displacement vector
% outCELL{,5} - number of observations for each point
% outCELL{,6} - slope of MSD vs. time linear fit
% outCELL{,7} - over cutoff flag

cs1 = size(cell1);
cs2 = size(cell2);
newlen = cs1(1)+cs2(2);

outCELL = cell(newlen,7);

for i=1:cs1(1)
    outCELL{i,1} = cell1{i,1};
    outCELL{i,2} = cell1{i,2};
    outCELL{i,3} = cell1{i,3};
    outCELL{i,4} = cell1{i,4};
    outCELL{i,5} = cell1{i,5};
    outCELL{i,6} = cell1{i,6};
    outCELL{i,7} = cell1{i,7};
end

for i=1:cs2(1)
    outCELL{cs1(1)+i,1} = cell2{i,1};
    outCELL{cs1(1)+i,2} = cell2{i,2};
    outCELL{cs1(1)+i,3} = cell2{i,3};
    outCELL{cs1(1)+i,4} = cell2{i,4};
    outCELL{cs1(1)+i,5} = cell2{i,5};
    outCELL{cs1(1)+i,6} = cell2{i,6};
    outCELL{cs1(1)+i,7} = cell2{i,7};
end

return
end